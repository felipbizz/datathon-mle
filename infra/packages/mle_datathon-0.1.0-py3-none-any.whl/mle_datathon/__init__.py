from mle_datathon.datathon import ModelRegister
from mle_datathon.model.train_model import train