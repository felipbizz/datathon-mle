from mlflow.tracking import MlflowClient

class ModelRegister():
    def __init__(self, client: MlflowClient):
        self.client = client

    def purge_registered_models(self):
        """
        Remove all registered models from the MLflow tracking server.
        """
        
        for rm in self.client.search_registered_models():
            self.client.delete_registered_model(name=rm.name)

    def list_registered_models(self):
        """
        List all registered models from the MLflow tracking server.
        """

        registered_models = {
            "models" : []
        }
        
        for rm in self.client.search_registered_models():
            model = {
                "name": rm.name,
                "version": rm.latest_versions[0].version,
                "status": rm.latest_versions[0].current_stage,
                "description": rm.description,
                "run_id": rm.latest_versions[0].run_id,
                "creation_time": rm.creation_timestamp,
                "last_updated_time": rm.last_updated_timestamp,
                "tags": rm.tags,
            }
            registered_models["models"].append(model)

        return registered_models